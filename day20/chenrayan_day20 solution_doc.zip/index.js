let str = "let's slice this string.";
console.log(str.slice(6, 11));

// replace
let str1 = "Today is a dummy day.";
console.log(str1.replace("dummy", "great"));
// capitalize
let str2 = "Today is a greate day";
console.log(str2.toUpperCase());

// concatenate
let str3 = "welcome to Veranda";
let str4 = "Today is a great day";
console.log(str4.concat(str3));

let str5 =
  "        Lorem ipsum dolor, sit amet consectetur Repudiandae,et nesciunt!        ";
console.log(str5.trim());
