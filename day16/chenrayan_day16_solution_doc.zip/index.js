let x = `Number string bigint boolean undefined object symbol`;
let a = 25;
let message = "hello";
let bigint = 5452541314n;
let isAlpha = true;
let pmc;
let date = Date();
let arrey = [
  [1, 2, 3, 4, 5],
  { name: "Girish", age: 24, email: "test@gmail.com" },
  date,
  15,
];
let y = `object dbject object function`;
console.log(x);
console.log(a, message, bigint, isAlpha, pmc);
console.log(y);
console.log(arrey);
